export function extend(to: any, from: any) {
    return (Object as any).assign(to, from);
}
