import { Langs } from '../interfaces/langs';
declare const en: Langs;
export default en;
