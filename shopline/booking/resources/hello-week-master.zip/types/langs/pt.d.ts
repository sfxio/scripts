import { Langs } from '../interfaces/langs';
declare const pt: Langs;
export default pt;
