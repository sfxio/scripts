import { Langs } from '../interfaces/langs';
declare const es: Langs;
export default es;
