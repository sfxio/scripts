import { Langs } from '../interfaces/langs';
declare const it: Langs;
export default it;
