import { Langs } from '../interfaces/langs';
declare const zh: Langs;
export default zh;
