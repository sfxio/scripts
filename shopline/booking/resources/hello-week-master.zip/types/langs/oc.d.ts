import { Langs } from '../interfaces/langs';
declare const oc: Langs;
export default oc;
