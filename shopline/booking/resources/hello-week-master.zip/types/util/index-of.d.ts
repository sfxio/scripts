export declare function getIndexForEventTarget(daysOfMonth: any, target: HTMLElement): number;
