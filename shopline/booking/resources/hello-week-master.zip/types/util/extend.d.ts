export declare function extend(to: any, from: any): any;
