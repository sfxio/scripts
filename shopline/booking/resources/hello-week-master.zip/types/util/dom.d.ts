export declare function setAttr(el: HTMLElement, name: string, value: string): void;
export declare function setStyle(el: HTMLElement, prop: string, value: string): void;
export declare function addClass(el: HTMLElement, className: string): void;
export declare function removeClass(el: HTMLElement, className: string): void;
export declare function toggleClass(el: HTMLElement, className: string): boolean;
export declare function existElement(className: string, where: HTMLElement): Element;
