declare function h(nodeName: string, attributes: any, ...args: any): any;
export declare function render(vnode: any, parentDom?: HTMLElement): any;
export { h as el };
export { h as createElement };
