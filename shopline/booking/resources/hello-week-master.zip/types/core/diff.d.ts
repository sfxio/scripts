export declare function diff(start: any, end: any): any[];
