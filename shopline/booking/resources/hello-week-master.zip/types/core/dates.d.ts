export declare function date(dt?: any): any;
