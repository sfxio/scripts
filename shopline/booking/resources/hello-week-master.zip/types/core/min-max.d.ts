export declare function setMinDate(dt: number | string): string;
export declare function setMaxDate(dt: number | string): string;
