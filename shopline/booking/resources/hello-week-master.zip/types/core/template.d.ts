import { Options, Template } from '../interfaces/index';
export declare function template(options: Options, args: any): Template;
