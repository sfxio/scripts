export declare function getIntervalOfDates(startDate: number, endDate: number): any[];
