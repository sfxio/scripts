export declare function createStore(state?: any): {
    setState: (update: any, overwrite?: boolean) => void;
    subscribe(listener: any): () => void;
    unsubscribe: (listener: any) => void;
    getState(): any;
};
