import { CssClasses, CssStates, DaysWeek, RTL } from '../interfaces/index';
export declare const cssClasses: CssClasses;
export declare const cssStates: CssStates;
export declare const daysWeek: DaysWeek;
export declare const margins: RTL;
