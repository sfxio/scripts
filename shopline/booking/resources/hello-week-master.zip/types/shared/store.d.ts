import { StoreOptions, StoreLangs } from '../interfaces/index';
export declare const useOptions: StoreOptions;
export declare const useLangs: StoreLangs;
