import { Options } from '../interfaces/index';
export declare const defaults: Options;
