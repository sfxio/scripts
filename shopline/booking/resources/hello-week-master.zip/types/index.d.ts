import { HelloWeek as Calendar } from './core/calendar';
import './styles/main.scss';
export declare const HelloWeek: typeof Calendar;
export default Calendar;
export { el, createElement, render } from './util/index';
